# FinMindBook


* [FinMind 架構獨家解析書籍推薦](https://www.tenlong.com.tw/products/9786267273739?list_name=b-r7-zh_tw)
<a href="https://www.tenlong.com.tw/products/9786267273739?list_name=b-r7-zh_tw"><img src="https://github.com/FinMind/FinMindBook/blob/master/DataEngineering/FinMindBook.jpg" width="200" height="250" alt=""/></a>


討論區 https://www.facebook.com/groups/401634838071226
