def crawler_taiwan_stock_price():
    print("crawler_taiwan_stock_price")


if __name__ == "__main__":
    crawler_taiwan_stock_price()
