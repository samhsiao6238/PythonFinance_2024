# FinMindBook
FinMind Book

## run
    pipenv run flask run
