# FinMindBook
FinMind Book

## run
    pipenv run uvicorn main:app --reload --port 8888

