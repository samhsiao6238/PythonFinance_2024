SELECT Close, Date
FROM taiwan_stock_price
WHERE StockID = '2330'
order by Date